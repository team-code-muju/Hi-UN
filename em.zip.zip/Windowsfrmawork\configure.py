import sys

if __name__ == "__main__":
    import ui.configure
    ui.configure.fmain(sys.argv)  