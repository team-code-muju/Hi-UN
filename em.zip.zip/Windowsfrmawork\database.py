# -*- coding: utf-8 -*-

'''
This Source Code Form is subject to the terms of the Mozilla
Public License, v. 2.0. If a copy of the MPL was not distributed
with this file, You can obtain one at http://mozilla.org/MPL/2.0/.
'''

import os
import utils
import json
import struct

'''
DATA FILE
HEAD: 
    SIZE: 8 BYTE
RAW:
    BLOCKSIZE: 4 BYTE 
    DATASIZE: 4 BYTE -- MAX SIZE = size(c_uint32)-8
    DATA: DATASIZE BYTES
    BLOCKSIZE: 4 BYTE
'''

VERSION=1

class Catalog():

    def __init__(self, name):
        self._path="data" + os.sep + name
        if not utils.path_exists(self._path):
            utils.path_makedirs(self._path)
    
    def table(self, name):
        return Table(self._path + os.sep + name) 


class Table():
    
    def __init__(self, path):
        self._path_stat=path + ".stat"
        self._jostat=None
        if utils.path_exists(self._path_stat):
            f = utils.file_open(self._path_stat,"rb")
            self._jostat=json.loads(f.read());
            f.close()
        else:
            jostat={"version": VERSION}
            f = utils.file_open(self._path_stat,"wb")
            f.write(json.dumps(jostat))
            f.close()
        self._path_data=path + ".data"
        if not utils.path_exists(self._path_data):
            f = utils.file_open(self._path_data,"wb")
            f.close()
    
    def insert(self, data):
        f = utils.file_open(self._path_data,"ab")
        dt = json.dumps(data, encoding="utf-8", ensure_ascii=False)
        dtsz = len(dt)
        bksz = 4+dtsz+int((dtsz*30.0)/100.0)
        f.write("".join([struct.pack("II",bksz,dtsz),dt," "*(bksz-dtsz-4),struct.pack("I",bksz)]))
        f.close()
    
    def all(self):
        return self.search(None)
    
    def search(self, query):
        lst = []
        fpos = 0
        fsize = os.path.getsize(self._path_data)
        f = utils.file_open(self._path_data,"rb")
        while fpos<fsize:
            ar = struct.unpack("II",f.read(8))
            bksz = ar[0]
            dtsz = ar[1]
            if dtsz>0:
                dt = json.loads(f.read(dtsz), encoding="utf-8")
                lst.append(dt)
            fpos+=4+bksz+4
            f.seek(fpos)
        f.close()
        return lst
        
class Query():
    
    def __init__(self):
        None
