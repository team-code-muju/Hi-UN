import sys

if __name__ == "__main__":
    import ui.monitor
    ui.monitor.fmain(sys.argv)  