import sys

if __name__ == "__main__":
    import ui.installer
    ui.installer.fmain(sys.argv)  